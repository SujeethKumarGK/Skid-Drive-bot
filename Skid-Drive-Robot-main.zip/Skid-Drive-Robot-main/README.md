# Skid-Drive-Robot
Skid-Dive-Robot is a 4 wheeled robot,we designed the robot in fusion360,model link is provided below and withe the help of fusion360tourdf file and from the roswiki and gazebo plugins we made the connection between topics.Here the robot is made for moving in a particular lane commonly called lane-following robot.Also added web interface where u can control the movement of robot using web and from anywhere.it is in robot_gui_bridge.
And we are still working on it to make it autonomous.

contributors:

@SujeethKumarGK



https://a360.co/3pJfCJH

http://gazebosim.org/tutorials?tut=ros_gzplugins
